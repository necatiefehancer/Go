package files

import "fmt"

func Total() {
	fmt.Println("total")
}
